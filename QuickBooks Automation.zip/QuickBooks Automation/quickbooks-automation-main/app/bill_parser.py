"""Vendor-agnostic bill PDF parser.

Best-effort extraction of the fields needed to enter a vendor bill:
invoice/ref number, invoice date, total, tax amounts, and candidate
charge lines (label + amount). Everything returned here is a *suggestion*
that the entry UI lets the user confirm or override — this module never
validates against QuickBooks and never rejects a bill.

Two document types are distinguished (doc_type in the result):
  "bill"      — a single-vendor invoice; one total, optional tax lines.
  "statement" — a credit-card/account statement with a running
                transaction table (date / posting date / description /
                amount). Every transaction row is extracted so each can
                become its own bill line, and the statement's own stated
                totals are captured for reconciliation.
"""
import re
from datetime import datetime

from pypdf import PdfReader

MONEY = r"-?\$?\s*-?[\d,]{1,12}\.\d{2}"

DATE_PATTERNS = [
    # "Jul 16, 2026" / "July 16 2026"
    (r"[A-Za-z]{3,9}\.?\s+\d{1,2},?\s+\d{4}",
     ["%b %d, %Y", "%B %d, %Y", "%b %d %Y", "%B %d %Y", "%b. %d, %Y"]),
    # "16 Jul 2026"
    (r"\d{1,2}\s+[A-Za-z]{3,9}\.?,?\s+\d{4}", ["%d %b %Y", "%d %B %Y"]),
    # "2026-07-16"
    (r"\d{4}-\d{2}-\d{2}", ["%Y-%m-%d"]),
    # "07/16/2026" (month-first assumed) / "07/16/26"
    (r"\d{1,2}[/-]\d{1,2}[/-]\d{2,4}",
     ["%m/%d/%Y", "%m/%d/%y", "%m-%d-%Y", "%d/%m/%Y"]),
]

DATE_LABELS = r"(?:invoice\s*date|date\s*of\s*issue|bill(?:ing)?\s*date|issued?|date)"

# Labels whose amounts are totals/taxes/etc., not enterable charge lines.
NON_CHARGE_WORDS = re.compile(
    r"total|subtotal|balance|amount\s*due|payment|paid|due|gst|hst|pst|qst"
    r"|vat|tax|remit|cheque|check|credit\s*card|page|account\s*number",
    re.IGNORECASE)

TAX_WORD = r"(?:GST|HST|PST|QST|VAT|Sales\s*Tax|Tax(?:es)?)"

# "Total QST - Telecom included in this bill $0.09" — label, trailing
# words tolerated, then the amount.
TAX_LABEL = re.compile(
    r"((?:[A-Za-z][A-Za-z ]{0,20})?" + TAX_WORD +
    r"(?:\s*\([A-Z]{2}\))?[A-Za-z \-()%]{0,40}?)"
    r"\s*(?:@\s*[\d.]+%)?\s*[:\s]*(" + MONEY + r")")

# "$4.25Total GST included in this bill" — two-column PDFs (e.g. Bell)
# render the amount before its label on the same extracted line.
AMOUNT_FIRST_LINE = re.compile(
    r"^\s*(-?\$\s*-?[\d,]{1,12}\.\d{2})\s*([A-Za-z][^\n]{0,70})$")

TOTAL_LABELS = [  # most specific first
    r"grand\s*total", r"total\s*due", r"amount\s*due", r"balance\s*due",
    r"invoice\s*total", r"total\s*amount", r"total",
]


def _to_float(value: str) -> float:
    value = value.replace(",", "").replace("$", "").replace(" ", "")
    # tolerate trailing-minus formats like "51.91-"
    if value.endswith("-"):
        value = "-" + value[:-1]
    return float(value)


def _find_date(text: str) -> str:
    """Labeled date first, then any date; returned as YYYY-MM-DD."""
    candidates = []
    for pattern, formats in DATE_PATTERNS:
        m = re.search(DATE_LABELS + r"\s*[:.\s]*\s*(" + pattern + r")",
                      text, re.IGNORECASE)
        if m:
            candidates.append((0, m.group(1), formats))
    if not candidates:
        for pattern, formats in DATE_PATTERNS:
            m = re.search(pattern, text)
            if m:
                candidates.append((1, m.group(0), formats))
    for _, raw, formats in sorted(candidates):
        for fmt in formats:
            try:
                return datetime.strptime(raw.strip(), fmt).strftime("%Y-%m-%d")
            except ValueError:
                continue
    return ""


def _find_invoice_number(text: str) -> str:
    label = r"invoice\s*(?:number|no\.?|num\.?|#|:)\s*[:#]?\s*"
    # Numeric (with dashes) first — stops cleanly even when the PDF glues the
    # next label on without a space ("...2-738-32725Account Number...").
    m = re.search(label + r"(\d[\d-]*\d|\d)", text, re.IGNORECASE)
    if m:
        return m.group(1)
    m = re.search(label + r"([A-Za-z]{1,6}[-/]?\d[\w/-]*)", text, re.IGNORECASE)
    if m:
        return m.group(1)
    return ""


def _find_total(text: str) -> float:
    """Pass layout-mode text when available: matching runs per line, in
    both "label ... amount" and "amount label" order (two-column PDFs)."""
    for lbl in TOTAL_LABELS:
        label_first = re.compile(
            lbl + r"\s*[:.\s]*(?:[A-Z]{3}\s*)?\$?\s*([\d,]+\.\d{2})",
            re.IGNORECASE)
        amount_first = re.compile(
            r"\$\s*([\d,]+\.\d{2})([^\d\n]{0,20}?)" + lbl, re.IGNORECASE)
        hits = []
        for line in text.splitlines():
            m = label_first.search(line)
            if m:
                hits.append(_to_float(m.group(1)))
            m = amount_first.search(line)
            if m and not re.search(r"previous|prior", m.group(2), re.IGNORECASE):
                hits.append(_to_float(m.group(1)))
        if hits:
            # The final "total" on an invoice is normally the payable amount.
            return hits[-1]
    amounts = [_to_float(a) for a in re.findall(r"\$\s*([\d,]+\.\d{2})", text)]
    return max(amounts) if amounts else 0.0


def _find_taxes(text: str, total: float) -> tuple:
    """((label, amount) tax pairs, best-guess tax total). Pass layout-mode
    text when available — matching runs per line, in both orders."""
    taxes, seen = [], set()
    for line in text.splitlines():
        pairs = TAX_LABEL.findall(line)
        m = AMOUNT_FIRST_LINE.match(line)
        if m and re.search(TAX_WORD, m.group(2)):
            pairs.append((m.group(2), m.group(1)))
        for label, amount in pairs:
            label = " ".join(label.split()).strip(" .:-")
            value = _to_float(amount)
            if value <= 0 or value >= total > 0:
                continue
            if re.search(r"subtotal|rate", label, re.IGNORECASE):
                continue
            key = (label.lower(), value)
            if key in seen:  # detail pages often repeat the summary's taxes
                continue
            seen.add(key)
            taxes.append({"label": label, "amount": value})

    # Lines like "Total GST included in this bill" are the per-tax totals;
    # when present they beat component lines ("OHST (8%) on telecom" is
    # already inside "Total HST"), which would double count.
    stated = [t for t in taxes if re.search(r"total", t["label"], re.IGNORECASE)]
    if stated:
        taxes = stated

    # An explicit tax subtotal beats summing lines (which can double count
    # when per-line detail repeats the invoice summary).
    m = re.search(r"(?:tax\s*subtotal|total\s*tax(?:es)?)\s*[:.\s]*\$?\s*([\d,]+\.\d{2})",
                  text, re.IGNORECASE)
    tax_total = _to_float(m.group(1)) if m else round(
        sum(t["amount"] for t in taxes), 2)
    return taxes, tax_total


# ---------- credit-card / account statements ----------

MONTHS = {}
for _i, _name in enumerate(
        ["January", "February", "March", "April", "May", "June", "July",
         "August", "September", "October", "November", "December"], 1):
    MONTHS[_name.lower()] = _i
    MONTHS[_name.lower()[:3]] = _i
MONTHS["sept"] = 9

# A transaction date cell: "JUN 3" / "3 JUN" / "06/03" / "06/03/26"
TXN_DATE = (r"(?:[A-Za-z]{3,9}\.?\s?\d{1,2}|\d{1,2}\s[A-Za-z]{3,9}\.?|"
            r"\d{1,2}[/-]\d{1,2}(?:[/-]\d{2,4})?)")
TXN_AMOUNT = r"-?\$?\s?-?[\d,]{1,12}\.\d{2}"

TXN_ROW_PATTERNS = [
    # "JUN 3 JUN 8 $398.92AIR CAN* ..." — two dates, $amount glued to the
    # description (TD statements extract this way).
    re.compile(r"^\s*(?P<d1>" + TXN_DATE + r")\s+(?P<d2>" + TXN_DATE + r")\s+"
               r"(?P<amt>-?\$\s?-?[\d,]{1,12}\.\d{2})(?P<desc>.*)$"),
    # "JUN 3 JUN 8 SOME MERCHANT 398.92" — two dates, amount last.
    re.compile(r"^\s*(?P<d1>" + TXN_DATE + r")\s+(?P<d2>" + TXN_DATE + r")\s+"
               r"(?P<desc>.*?\S)\s+(?P<amt>" + TXN_AMOUNT + r")(?P<cr>\s*CR)?\s*$"),
    # "JUN 3 SOME MERCHANT 398.92" — one date, amount last.
    re.compile(r"^\s*(?P<d1>" + TXN_DATE + r")\s+"
               r"(?P<desc>.*?\S)\s+(?P<amt>" + TXN_AMOUNT + r")(?P<cr>\s*CR)?\s*$"),
]

# A page only counts as a transaction table if it has a header like
# "DATE ... ACTIVITY DESCRIPTION ... AMOUNT" or several row matches.
TABLE_HEADER = re.compile(
    r"date.{0,80}?(?:description|activity|merchant)[^\n]{0,80}?amount",
    re.IGNORECASE | re.DOTALL)

STATEMENT_MARKERS = [
    r"statement\s*(?:date|period)", r"minimum\s*payment", r"credit\s*limit",
    r"payment\s*due\s*date", r"new\s*balance", r"previous\s*balance",
    r"cash\s*advance", r"annual\s*interest\s*rate",
]

# Lines that end a wrapped-description continuation.
CONT_STOP = re.compile(
    r"continued|total|balance|subtotal|statement|minimum\s*payment"
    r"|payment\s*due|page\s*\d|_", re.IGNORECASE)

PAYMENT_WORDS = re.compile(r"payment|thank\s*you", re.IGNORECASE)


def _parse_txn_date(raw: str):
    """'JUN 3' / '3 JUN' / '06/03' -> (month, day), or None if not a date."""
    raw = raw.strip()
    m = re.match(r"^([A-Za-z]{3,9})\.?\s?(\d{1,2})$", raw)
    if m:
        month = MONTHS.get(m.group(1).lower())
        return (month, int(m.group(2))) if month else None
    m = re.match(r"^(\d{1,2})\s([A-Za-z]{3,9})\.?$", raw)
    if m:
        month = MONTHS.get(m.group(2).lower())
        return (month, int(m.group(1))) if month else None
    m = re.match(r"^(\d{1,2})[/-](\d{1,2})(?:[/-]\d{2,4})?$", raw)
    if m:
        month, day = int(m.group(1)), int(m.group(2))
        if month > 12 >= day:
            month, day = day, month
        if 1 <= month <= 12 and 1 <= day <= 31:
            return month, day
    return None


def _match_row(line: str):
    """(date_raw, description, amount) if the line is a transaction row."""
    for pattern in TXN_ROW_PATTERNS:
        m = pattern.match(line)
        if not m:
            continue
        if not _parse_txn_date(m.group("d1")):
            continue
        d2 = m.groupdict().get("d2")
        if d2 and not _parse_txn_date(d2):
            continue
        desc = m.group("desc").strip()
        if not re.search(r"[A-Za-z]", desc):
            continue
        amount = _to_float(m.group("amt"))
        if m.groupdict().get("cr"):  # "12.34 CR" means a credit
            amount = -abs(amount)
        return m.group("d1"), desc, amount
    return None


def _is_continuation(line: str) -> bool:
    """A short trailing fragment of the previous row's description
    (wrapped city name, FOREIGN CURRENCY note, ...)."""
    s = line.strip()
    return (0 < len(s) <= 45 and bool(re.search(r"[A-Za-z]", s))
            and not CONT_STOP.search(s) and not _match_row(line))


def _extract_transactions(page_texts: list) -> tuple:
    """All transaction rows from pages that look like transaction tables.
    Returns (transactions, set of consumed source lines)."""
    txns, used = [], set()
    for page in page_texts:
        lines = page.splitlines()
        page_txns, page_used = [], []
        i = 0
        while i < len(lines):
            row = _match_row(lines[i])
            if not row:
                i += 1
                continue
            date_raw, desc, amount = row
            page_used.append(lines[i])
            cont = 0
            while (i + 1 < len(lines) and cont < 3
                   and _is_continuation(lines[i + 1])):
                i += 1
                cont += 1
                desc += " " + lines[i].strip()
                page_used.append(lines[i])
            page_txns.append({"date_raw": date_raw,
                              "description": " ".join(desc.split()),
                              "amount": amount})
            i += 1
        if page_txns and (len(page_txns) >= 3 or TABLE_HEADER.search(page)):
            txns.extend(page_txns)
            used.update(page_used)
    return txns, used


def _statement_score(text: str) -> int:
    return sum(bool(re.search(m, text, re.IGNORECASE))
               for m in STATEMENT_MARKERS)


def _find_statement_date(text: str) -> str:
    m = re.search(r"statement\s*date\s*:?\s*"
                  r"([A-Za-z]{3,9}\.?\s+\d{1,2},?\s+\d{4}"
                  r"|\d{4}-\d{2}-\d{2}|\d{1,2}[/-]\d{1,2}[/-]\d{2,4})",
                  text, re.IGNORECASE)
    if m:
        for fmt in ("%B %d, %Y", "%b %d, %Y", "%b. %d, %Y", "%B %d %Y",
                    "%b %d %Y", "%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y"):
            try:
                return datetime.strptime(m.group(1).strip(), fmt).strftime("%Y-%m-%d")
            except ValueError:
                continue
    return _find_date(text)


def _stated_amount(text: str, *labels) -> float:
    """First labelled dollar figure, e.g. 'Purchases & Other Charges $19,445.02'."""
    for label in labels:
        m = re.search(label + r"\s*:?\s*\$?\s*(-?[\d,]+\.\d{2})(?!\s*%)",
                      text, re.IGNORECASE)
        if m:
            return _to_float(m.group(1))
    return 0.0


def _txn_date_iso(raw: str, statement_date: str) -> str:
    """Transaction date as YYYY-MM-DD, inferring the year from the
    statement date (a December row on a January statement is last year)."""
    parsed = _parse_txn_date(raw)
    if not parsed:
        return ""
    month, day = parsed
    year, stmt_month = datetime.now().year, 0
    if statement_date:
        year, stmt_month = int(statement_date[:4]), int(statement_date[5:7])
    if stmt_month and month > stmt_month:
        year -= 1
    try:
        return datetime(year, month, day).strftime("%Y-%m-%d")
    except ValueError:
        return ""


def _clean_label(label: str) -> str:
    """Trim glued-together PDF text ("Signed byC.ChristineFuel Surcharge")
    down to the last naturally-cased phrase ("Fuel Surcharge")."""
    label = " ".join(label.split()).strip(" .:-")
    parts = re.split(r"(?<=[a-z0-9.,])(?=[A-Z])", label)
    return parts[-1].strip(" .:-,")


def _find_charge_candidates(text: str, total: float) -> list:
    """Label+amount pairs that could be bill lines, for one-click adding."""
    candidates, seen = [], set()
    pattern = re.compile(
        r"([A-Za-z][A-Za-z0-9 &/().,'#-]{2,60}?)\s*\$?\s*(-?[\d,]+\.\d{2})(?!\d|%)")
    for label, amount in pattern.findall(text):
        label = _clean_label(label)
        value = _to_float(amount)
        if not label or NON_CHARGE_WORDS.search(label):
            continue
        if len(label) < 3 or value == 0:
            continue
        if total and abs(value) > total * 1.5:
            continue
        key = (label.lower(), value)
        if key in seen:
            continue
        seen.add(key)
        candidates.append({"label": label, "amount": value})
        if len(candidates) >= 60:
            break
    return candidates


def parse_bill(file_path: str) -> dict:
    """Parse any vendor's bill or statement PDF. Every field is best-effort;
    missing values come back empty/0 rather than raising."""
    reader = PdfReader(str(file_path))
    page_texts = [page.extract_text() or "" for page in reader.pages]
    text = "\n".join(page_texts)

    transactions, used_lines = _extract_transactions(page_texts)
    if len(transactions) >= 5 and _statement_score(text) >= 3:
        return _parse_statement(text, transactions, used_lines)

    # Layout mode keeps each visual line together, so a two-column summary
    # ("$1,045.72Total amount due") can be matched line by line instead of
    # amounts gluing onto the next line's label.
    try:
        layout_text = "\n".join(page.extract_text(extraction_mode="layout") or ""
                                for page in reader.pages)
    except Exception:
        layout_text = text

    total = _find_total(layout_text)
    taxes, tax_total = _find_taxes(layout_text, total)

    return {
        "doc_type": "bill",
        "invoice_number": _find_invoice_number(text),
        "invoice_date": _find_date(text),
        "total": total,
        "taxes": taxes,
        "tax_total": tax_total,
        "pre_tax_total": round(total - tax_total, 2) if total else 0.0,
        "charge_candidates": _find_charge_candidates(text, total),
        "statement": None,
        "text": text,
        "vendor_text": text,
    }


def _parse_statement(text: str, transactions: list, used_lines: set) -> dict:
    statement_date = _find_statement_date(text)
    for t in transactions:
        t["date"] = _txn_date_iso(t["date_raw"], statement_date)
        # A negative "PAYMENT" row is the cardholder paying the card —
        # not an expense line. Refunds/credits stay enterable (negative).
        t["is_payment"] = (t["amount"] < 0
                           and bool(PAYMENT_WORDS.search(t["description"])))

    charges = round(sum(t["amount"] for t in transactions if t["amount"] > 0), 2)
    credits = round(sum(t["amount"] for t in transactions if t["amount"] < 0), 2)
    stated_purchases = _stated_amount(
        text, r"purchases\s*(?:&|and)\s*other\s*charges", r"total\s*purchases")
    total = stated_purchases or charges

    # Vendor guessing must ignore the transaction rows themselves, so a
    # merchant in the list (e.g. Bell Canada) can't be mistaken for the
    # card issuer named in the header/remittance area.
    used = set(used_lines)
    vendor_text = "\n".join(l for l in text.splitlines() if l not in used)

    return {
        "doc_type": "statement",
        "invoice_number": "",
        "invoice_date": statement_date,
        "total": total,
        "taxes": [],
        "tax_total": 0.0,
        "pre_tax_total": total,
        "charge_candidates": [
            {"label": f'{t["date"] or t["date_raw"]} {t["description"]}',
             "amount": t["amount"]} for t in transactions],
        "statement": {
            "statement_date": statement_date,
            "transactions": transactions,
            "charges_total": charges,
            "credits_total": credits,
            "stated_purchases": stated_purchases,
            "stated_payments_credits": _stated_amount(
                text, r"payments\s*(?:&|and)\s*credits"),
            "stated_new_balance": _stated_amount(
                text, r"(?:total\s*)?new\s*balance"),
            "stated_previous_balance": _stated_amount(
                text, r"previous\s*(?:statement\s*)?balance"),
        },
        "text": text,
        "vendor_text": vendor_text,
    }


def guess_vendor(text: str, vendor_names: list) -> str:
    """Pick the QuickBooks vendor whose name appears in the PDF text.

    The live vendor list is the source of truth — nothing is hardcoded.
    Longest match wins (so "FedEx Freight" beats "FedEx" when both appear).
    Matching ignores punctuation/symbols, so "TD® Aeroplan® Visa*" in the
    PDF still matches a vendor named "TD Aeroplan Visa".
    """
    def norm(s):
        return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9&]", " ", s.lower())).strip()

    lowered = norm(text)
    best, best_len = "", 0
    for name in vendor_names:
        display = norm(name.split(":")[-1])
        if len(display) >= 3 and display in lowered and len(display) > best_len:
            best, best_len = name, len(display)
    return best


if __name__ == "__main__":
    import json
    import sys

    result = parse_bill(sys.argv[1])
    result.pop("text")
    result.pop("vendor_text")
    print(json.dumps(result, indent=2))
