"""Vendor-agnostic bill PDF parser.

Best-effort extraction of the fields needed to enter a vendor bill:
invoice/ref number, invoice date, total, tax amounts, and candidate
charge lines (label + amount). Everything returned here is a *suggestion*
that the entry UI lets the user confirm or override — this module never
validates against QuickBooks and never rejects a bill.
"""
import re
from datetime import datetime

from pypdf import PdfReader

MONEY = r"-?\$?\s*-?[\d,]{1,12}\.\d{2}"

DATE_PATTERNS = [
    # "Jul 16, 2026" / "July 16 2026"
    (r"[A-Za-z]{3,9}\.?\s+\d{1,2},?\s+\d{4}",
     ["%b %d, %Y", "%B %d, %Y", "%b %d %Y", "%B %d %Y", "%b. %d, %Y"]),
    # "16 Jul 2026"
    (r"\d{1,2}\s+[A-Za-z]{3,9}\.?,?\s+\d{4}", ["%d %b %Y", "%d %B %Y"]),
    # "2026-07-16"
    (r"\d{4}-\d{2}-\d{2}", ["%Y-%m-%d"]),
    # "07/16/2026" (month-first assumed) / "07/16/26"
    (r"\d{1,2}[/-]\d{1,2}[/-]\d{2,4}",
     ["%m/%d/%Y", "%m/%d/%y", "%m-%d-%Y", "%d/%m/%Y"]),
]

DATE_LABELS = r"(?:invoice\s*date|date\s*of\s*issue|bill(?:ing)?\s*date|issued?|date)"

# Labels whose amounts are totals/taxes/etc., not enterable charge lines.
NON_CHARGE_WORDS = re.compile(
    r"total|subtotal|balance|amount\s*due|payment|paid|due|gst|hst|pst|qst"
    r"|vat|tax|remit|cheque|check|credit\s*card|page|account\s*number",
    re.IGNORECASE)

TAX_LABEL = re.compile(
    r"((?:[A-Za-z][A-Za-z ]{0,20})?(?:GST|HST|PST|QST|VAT|Sales\s*Tax|Tax)"
    r"(?:\s*\([A-Z]{2}\))?)\s*(?:@\s*[\d.]+%)?\s*[:\s]*(" + MONEY + r")")

TOTAL_LABELS = [  # most specific first
    r"grand\s*total", r"total\s*due", r"amount\s*due", r"balance\s*due",
    r"invoice\s*total", r"total\s*amount", r"total",
]


def _to_float(value: str) -> float:
    value = value.replace(",", "").replace("$", "").replace(" ", "")
    # tolerate trailing-minus formats like "51.91-"
    if value.endswith("-"):
        value = "-" + value[:-1]
    return float(value)


def _find_date(text: str) -> str:
    """Labeled date first, then any date; returned as YYYY-MM-DD."""
    candidates = []
    for pattern, formats in DATE_PATTERNS:
        m = re.search(DATE_LABELS + r"\s*[:.\s]*\s*(" + pattern + r")",
                      text, re.IGNORECASE)
        if m:
            candidates.append((0, m.group(1), formats))
    if not candidates:
        for pattern, formats in DATE_PATTERNS:
            m = re.search(pattern, text)
            if m:
                candidates.append((1, m.group(0), formats))
    for _, raw, formats in sorted(candidates):
        for fmt in formats:
            try:
                return datetime.strptime(raw.strip(), fmt).strftime("%Y-%m-%d")
            except ValueError:
                continue
    return ""


def _find_invoice_number(text: str) -> str:
    label = r"invoice\s*(?:number|no\.?|num\.?|#|:)\s*[:#]?\s*"
    # Numeric (with dashes) first — stops cleanly even when the PDF glues the
    # next label on without a space ("...2-738-32725Account Number...").
    m = re.search(label + r"(\d[\d-]*\d|\d)", text, re.IGNORECASE)
    if m:
        return m.group(1)
    m = re.search(label + r"([A-Za-z]{1,6}[-/]?\d[\w/-]*)", text, re.IGNORECASE)
    if m:
        return m.group(1)
    return ""


def _find_total(text: str) -> float:
    for lbl in TOTAL_LABELS:
        matches = re.findall(lbl + r"\s*[:.\s]*(?:[A-Z]{3}\s*)?\$?\s*([\d,]+\.\d{2})",
                             text, re.IGNORECASE)
        if matches:
            # The final "total" on an invoice is normally the payable amount.
            return _to_float(matches[-1])
    amounts = [_to_float(a) for a in re.findall(r"\$\s*([\d,]+\.\d{2})", text)]
    return max(amounts) if amounts else 0.0


def _find_taxes(text: str, total: float) -> tuple:
    """((label, amount) tax pairs, best-guess tax total)."""
    taxes, seen = [], set()
    for label, amount in TAX_LABEL.findall(text):
        label = " ".join(label.split())
        value = _to_float(amount)
        if value <= 0 or value >= total > 0:
            continue
        if re.search(r"subtotal|total|rate", label, re.IGNORECASE):
            continue
        key = (label.lower(), value)
        if key in seen:  # detail pages often repeat the summary's tax lines
            continue
        seen.add(key)
        taxes.append({"label": label, "amount": value})

    # An explicit tax subtotal beats summing lines (which can double count
    # when per-line detail repeats the invoice summary).
    m = re.search(r"(?:tax\s*subtotal|total\s*tax(?:es)?)\s*[:.\s]*\$?\s*([\d,]+\.\d{2})",
                  text, re.IGNORECASE)
    tax_total = _to_float(m.group(1)) if m else round(
        sum(t["amount"] for t in taxes), 2)
    return taxes, tax_total


def _clean_label(label: str) -> str:
    """Trim glued-together PDF text ("Signed byC.ChristineFuel Surcharge")
    down to the last naturally-cased phrase ("Fuel Surcharge")."""
    label = " ".join(label.split()).strip(" .:-")
    parts = re.split(r"(?<=[a-z0-9.,])(?=[A-Z])", label)
    return parts[-1].strip(" .:-,")


def _find_charge_candidates(text: str, total: float) -> list:
    """Label+amount pairs that could be bill lines, for one-click adding."""
    candidates, seen = [], set()
    pattern = re.compile(
        r"([A-Za-z][A-Za-z0-9 &/().,'#-]{2,60}?)\s*(-?[\d,]+\.\d{2})(?!\d|%)")
    for label, amount in pattern.findall(text):
        label = _clean_label(label)
        value = _to_float(amount)
        if not label or NON_CHARGE_WORDS.search(label):
            continue
        if len(label) < 3 or value == 0:
            continue
        if total and abs(value) > total * 1.5:
            continue
        key = (label.lower(), value)
        if key in seen:
            continue
        seen.add(key)
        candidates.append({"label": label, "amount": value})
        if len(candidates) >= 60:
            break
    return candidates


def parse_bill(file_path: str) -> dict:
    """Parse any vendor's bill PDF. Every field is best-effort; missing
    values come back empty/0 rather than raising."""
    reader = PdfReader(str(file_path))
    text = "\n".join(page.extract_text() or "" for page in reader.pages)

    total = _find_total(text)
    taxes, tax_total = _find_taxes(text, total)

    return {
        "invoice_number": _find_invoice_number(text),
        "invoice_date": _find_date(text),
        "total": total,
        "taxes": taxes,
        "tax_total": tax_total,
        "pre_tax_total": round(total - tax_total, 2) if total else 0.0,
        "charge_candidates": _find_charge_candidates(text, total),
        "text": text,
    }


def guess_vendor(text: str, vendor_names: list) -> str:
    """Pick the QuickBooks vendor whose name appears in the PDF text.

    The live vendor list is the source of truth — nothing is hardcoded.
    Longest match wins (so "FedEx Freight" beats "FedEx" when both appear).
    """
    lowered = re.sub(r"\s+", " ", text.lower())
    best = ""
    for name in vendor_names:
        display = name.split(":")[-1].strip().lower()
        if len(display) >= 3 and display in lowered and len(display) > len(best):
            best = name
    return best


if __name__ == "__main__":
    import json
    import sys

    result = parse_bill(sys.argv[1])
    result.pop("text")
    print(json.dumps(result, indent=2))
