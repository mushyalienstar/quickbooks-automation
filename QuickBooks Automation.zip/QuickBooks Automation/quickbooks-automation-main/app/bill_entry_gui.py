"""PDF bill -> QuickBooks vendor bill entry tool (any vendor).

Run inside the VM with QuickBooks Desktop open on the company file:

    python bill_entry_gui.py [optional-pdf-or-folder]

Open a bill PDF; the parser pre-fills vendor, ref number, date and the
detected amounts. Item, Account and Tax Code are DROPDOWNS populated live
from the open company file — whatever items/accounts/tax codes that file
actually has. Nothing is validated against hardcoded names, no reference
number / customer:job matching is attempted, and nothing blocks entry:
anything the parser couldn't figure out you just pick from a dropdown.
"""
import json
import shutil
import sys
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from bill_parser import guess_vendor, parse_bill
from qb_client import QB_AVAILABLE, QuickBooks

DEFAULTS_FILE = Path(__file__).with_name("vendor_defaults.json")
LINE_KINDS = ("Item", "Expense")


def load_vendor_defaults() -> dict:
    try:
        return json.loads(DEFAULTS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_vendor_defaults(defaults: dict):
    try:
        DEFAULTS_FILE.write_text(json.dumps(defaults, indent=2), encoding="utf-8")
    except Exception:
        pass  # defaults are a convenience, never fatal


class ScrollFrame(ttk.Frame):
    """Vertically scrollable frame — statements can have 60+ lines."""

    def __init__(self, parent):
        super().__init__(parent)
        self.canvas = tk.Canvas(self, highlightthickness=0)
        bar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = ttk.Frame(self.canvas)
        self._window = self.canvas.create_window((0, 0), window=self.inner,
                                                 anchor="nw")
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(
            scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(
            self._window, width=e.width))
        self.canvas.configure(yscrollcommand=bar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        bar.pack(side="right", fill="y")
        self.inner.bind("<Enter>", lambda e: self.canvas.bind_all(
            "<MouseWheel>", self._on_wheel))
        self.inner.bind("<Leave>", lambda e: self.canvas.unbind_all(
            "<MouseWheel>"))

    def _on_wheel(self, event):
        self.canvas.yview_scroll(-1 * (event.delta // 120), "units")


class LineRow:
    """One bill line: kind + name dropdown + amount + tax dropdown + memo."""

    def __init__(self, app: "BillEntryApp", parent: ttk.Frame):
        self.app = app
        self.frame = ttk.Frame(parent)

        self.kind = tk.StringVar(value="Item")
        self.kind_box = ttk.Combobox(self.frame, textvariable=self.kind,
                                     values=LINE_KINDS, width=8, state="readonly")
        self.kind_box.bind("<<ComboboxSelected>>", lambda e: self._kind_changed())

        self.name = tk.StringVar()
        self.name_box = ttk.Combobox(self.frame, textvariable=self.name, width=34)
        self.name_box.bind("<KeyRelease>", self._filter_names)

        self.amount = tk.StringVar()
        self.amount_entry = ttk.Entry(self.frame, textvariable=self.amount, width=10,
                                      justify="right")
        self.amount.trace_add("write", lambda *_: app.refresh_totals())

        self.tax = tk.StringVar()
        self.tax_box = ttk.Combobox(self.frame, textvariable=self.tax, width=8)

        self.memo = tk.StringVar()
        self.memo_entry = ttk.Entry(self.frame, textvariable=self.memo, width=30)

        remove = ttk.Button(self.frame, text="✕", width=3,
                            command=lambda: app.remove_line(self))

        for col, widget in enumerate((self.kind_box, self.name_box,
                                      self.amount_entry, self.tax_box,
                                      self.memo_entry, remove)):
            widget.grid(row=0, column=col, padx=(0, 6), sticky="w")

        self._kind_changed()
        self.tax_box["values"] = app.tax_codes

    def _all_names(self) -> list:
        return self.app.items if self.kind.get() == "Item" else self.app.accounts

    def _kind_changed(self):
        self.name_box["values"] = self._all_names()

    def _filter_names(self, _event=None):
        typed = self.name.get().strip().lower()
        names = self._all_names()
        self.name_box["values"] = (
            [n for n in names if typed in n.lower()] or names if typed else names)

    def to_dict(self):
        """None if the row is blank; raises ValueError with a reason if bad."""
        name, amount = self.name.get().strip(), self.amount.get().strip()
        if not name and not amount:
            return None
        if not name:
            raise ValueError("a line has an amount but no Item/Account selected")
        try:
            value = round(float(amount.replace(",", "").replace("$", "")), 2)
        except ValueError:
            raise ValueError(f'line "{name}" has a bad amount: {amount!r}')
        return {"kind": self.kind.get().lower(), "name": name, "amount": value,
                "tax_code": self.tax.get().strip(), "memo": self.memo.get().strip()}


class BillEntryApp(tk.Tk):
    def __init__(self, qb):
        super().__init__()
        self.qb = qb
        self.title("Bill Entry — PDF → QuickBooks")
        self.geometry("1020x680")
        self.minsize(860, 560)

        self.vendors, self.items, self.accounts, self.tax_codes = [], [], [], []
        self.vendor_defaults = load_vendor_defaults()
        self.pdf_path = None
        self.parsed = None
        self.rows = []

        self._build_ui()
        self.refresh_lists()

    # ---------- UI construction ----------

    def _build_ui(self):
        pad = {"padx": 8, "pady": 4}

        top = ttk.Frame(self)
        top.pack(fill="x", **pad)
        ttk.Button(top, text="Open PDF…", command=self.open_pdf).pack(side="left")
        ttk.Button(top, text="Refresh QuickBooks lists",
                   command=self.refresh_lists).pack(side="left", padx=8)
        self.conn_label = ttk.Label(top, text="", foreground="gray")
        self.conn_label.pack(side="right")

        head = ttk.LabelFrame(self, text="Bill")
        head.pack(fill="x", **pad)
        self.vendor = tk.StringVar()
        self.ref = tk.StringVar()
        self.date = tk.StringVar()
        self.memo = tk.StringVar()

        ttk.Label(head, text="Vendor").grid(row=0, column=0, sticky="e", **pad)
        self.vendor_box = ttk.Combobox(head, textvariable=self.vendor, width=36)
        self.vendor_box.grid(row=0, column=1, sticky="w", **pad)
        ttk.Label(head, text="Ref No.").grid(row=0, column=2, sticky="e", **pad)
        ttk.Entry(head, textvariable=self.ref, width=18).grid(
            row=0, column=3, sticky="w", **pad)
        ttk.Label(head, text="Date (YYYY-MM-DD)").grid(row=0, column=4, sticky="e", **pad)
        ttk.Entry(head, textvariable=self.date, width=12).grid(
            row=0, column=5, sticky="w", **pad)
        ttk.Label(head, text="Memo").grid(row=1, column=0, sticky="e", **pad)
        ttk.Entry(head, textvariable=self.memo, width=60).grid(
            row=1, column=1, columnspan=3, sticky="w", **pad)
        self.parsed_label = ttk.Label(head, text="No PDF loaded.", foreground="gray")
        self.parsed_label.grid(row=1, column=4, columnspan=2, sticky="w", **pad)

        body = ttk.Frame(self)
        body.pack(fill="both", expand=True, **pad)
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        body.rowconfigure(0, weight=1)

        lines_frame = ttk.LabelFrame(body, text="Lines")
        lines_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        header = ttk.Frame(lines_frame)
        header.pack(fill="x", padx=6, pady=(6, 0))
        for text, width in (("Type", 10), ("Item / Account", 37), ("Amount", 11),
                            ("Tax", 10), ("Memo", 30)):
            ttk.Label(header, text=text, width=width,
                      font=("", 9, "bold")).pack(side="left")
        self.lines_scroll = ScrollFrame(lines_frame)
        self.lines_scroll.pack(fill="both", expand=True, padx=6, pady=6)
        self.lines_container = self.lines_scroll.inner
        ttk.Button(lines_frame, text="+ Add line",
                   command=self.add_line).pack(anchor="w", padx=6, pady=(0, 6))

        cand_frame = ttk.LabelFrame(body, text="Amounts detected in PDF (double-click to add as line)")
        cand_frame.grid(row=0, column=1, sticky="nsew")
        self.cand_list = tk.Listbox(cand_frame)
        self.cand_list.pack(fill="both", expand=True, padx=6, pady=6)
        self.cand_list.bind("<Double-Button-1>", self.add_candidate)

        bottom = ttk.Frame(self)
        bottom.pack(fill="x", **pad)
        self.totals_label = ttk.Label(bottom, text="", font=("", 10))
        self.totals_label.pack(side="left")
        self.enter_btn = ttk.Button(bottom, text="Enter Bill in QuickBooks",
                                    command=self.enter_bill)
        self.enter_btn.pack(side="right")

        self.status = tk.Text(self, height=4, state="disabled", wrap="word")
        self.status.pack(fill="x", padx=8, pady=(0, 8))

    # ---------- QuickBooks lists (live, never hardcoded) ----------

    def refresh_lists(self):
        if not self.qb:
            self.conn_label.config(
                text="QuickBooks NOT connected — preview only", foreground="red")
            self.enter_btn.state(["disabled"])
            return
        try:
            self.vendors = self.qb.vendors()
            self.items = self.qb.items()
            self.accounts = self.qb.accounts()
            self.tax_codes = [""] + self.qb.tax_codes()
        except Exception as e:
            self.log(f"Could not load QuickBooks lists: {e}")
            return
        self.vendor_box["values"] = self.vendors
        for row in self.rows:
            row._kind_changed()
            row.tax_box["values"] = self.tax_codes
        product = self.qb.host_info()
        self.conn_label.config(
            text=f"Connected: {product}  ({len(self.vendors)} vendors, "
                 f"{len(self.items)} items, {len(self.accounts)} accounts, "
                 f"{len(self.tax_codes) - 1} tax codes)",
            foreground="dark green")
        self.enter_btn.state(["!disabled"])

    # ---------- PDF loading ----------

    def open_pdf(self, path: str = None):
        if not path:
            path = filedialog.askopenfilename(
                title="Open bill PDF", filetypes=[("PDF files", "*.pdf")])
        if not path:
            return
        self.pdf_path = Path(path)
        try:
            self.parsed = parse_bill(path)
        except Exception as e:
            messagebox.showerror("Parse error", f"Could not read {path}:\n{e}")
            return

        p = self.parsed
        self.ref.set(p["invoice_number"])
        self.date.set(p["invoice_date"])
        self.memo.set(self.pdf_path.name)
        # For statements, vendor_text excludes the transaction rows, so a
        # line-item merchant can't be mistaken for the card issuer.
        vendor = guess_vendor(p["vendor_text"], self.vendors)
        self.vendor.set(vendor)

        self.cand_list.delete(0, "end")
        for c in p["charge_candidates"]:
            self.cand_list.insert("end", f'{c["amount"]:>10.2f}   {c["label"]}')

        for row in list(self.rows):
            self.remove_line(row)

        if p["doc_type"] == "statement":
            self._load_statement(p)
        else:
            # One line pre-filled with the pre-tax amount — the usual case
            # where the whole bill goes to one item/account and the tax code
            # adds tax.
            row = self.add_line()
            if p["pre_tax_total"]:
                row.amount.set(f'{p["pre_tax_total"]:.2f}')
            taxes = ", ".join(f'{t["label"]} {t["amount"]:.2f}'
                              for t in p["taxes"][:4])
            self.parsed_label.config(
                text=f'PDF total {p["total"]:.2f}  (tax {p["tax_total"]:.2f}'
                     + (f": {taxes}" if taxes else "") + ")",
                foreground="black")
            self.log(f"Loaded {self.pdf_path.name}. Check the pre-filled fields, "
                     f"pick Item/Account and Tax from the dropdowns, then Enter Bill.")

        self.title(f"Bill Entry — {self.pdf_path.name}")
        self.refresh_totals()

    def _load_statement(self, p: dict):
        """One line per statement transaction. Item/Account is left blank on
        purpose — pick each from the dropdown; nothing is silently defaulted."""
        s = p["statement"]
        if s["statement_date"]:
            self.ref.set(f'Stmt {s["statement_date"]}')
        skipped = 0
        for t in s["transactions"]:
            if t["is_payment"]:  # paying the card isn't an expense line
                skipped += 1
                continue
            row = self.add_line(apply_defaults=False)
            row.kind.set("Expense")
            row._kind_changed()
            row.amount.set(f'{t["amount"]:.2f}')
            row.memo.set(f'{t["date"] or t["date_raw"]} {t["description"]}')

        target = s["stated_purchases"] or s["charges_total"]
        matches = abs(s["charges_total"] - target) < 0.005
        self.parsed_label.config(
            text=f'Statement: {len(s["transactions"])} transactions, charges '
                 f'{s["charges_total"]:.2f} vs stated {target:.2f} '
                 f'{"✓" if matches else "✗ MISMATCH"}',
            foreground="dark green" if matches else "red")
        self.log(f'Loaded {self.pdf_path.name} as a CREDIT CARD STATEMENT: '
                 f'{len(s["transactions"])} transactions'
                 + (f" ({skipped} card-payment row(s) excluded)" if skipped else "")
                 + ". Vendor should be the card issuer. Each line's Account is "
                   "left blank — pick one per line (or delete lines you don't "
                   "want) before entering.")

    # ---------- lines ----------

    def add_line(self, apply_defaults: bool = True) -> LineRow:
        row = LineRow(self, self.lines_container)
        row.frame.pack(fill="x", pady=2)
        self.rows.append(row)
        d = self.vendor_defaults.get(self.vendor.get().strip()) \
            if apply_defaults else None
        if d:  # last-used choice for this vendor, purely a convenience
            if d.get("kind") in LINE_KINDS:
                row.kind.set(d["kind"])
                row._kind_changed()
            if d.get("name") in row._all_names():
                row.name.set(d["name"])
            if d.get("tax_code") in self.tax_codes:
                row.tax.set(d["tax_code"])
        return row

    def remove_line(self, row: LineRow):
        row.frame.destroy()
        self.rows.remove(row)
        self.refresh_totals()

    def add_candidate(self, _event=None):
        sel = self.cand_list.curselection()
        if not sel or not self.parsed:
            return
        c = self.parsed["charge_candidates"][sel[0]]
        # Reuse the single empty pre-filled row before growing the list.
        row = None
        for r in self.rows:
            if not r.name.get().strip() and not r.memo.get().strip():
                row = r
                break
        row = row or self.add_line()
        row.amount.set(f'{c["amount"]:.2f}')
        row.memo.set(c["label"])
        self.refresh_totals()

    def refresh_totals(self):
        amounts = []
        for row in self.rows:
            try:
                amounts.append(
                    float(row.amount.get().replace(",", "").replace("$", "")))
            except ValueError:
                pass
        total = sum(amounts)

        if self.parsed and self.parsed["doc_type"] == "statement":
            s = self.parsed["statement"]
            charges = sum(a for a in amounts if a > 0)
            credits = sum(a for a in amounts if a < 0)
            target = s["stated_purchases"] or s["charges_total"]
            ok = abs(charges - target) < 0.005
            self.totals_label.config(
                text=f'Charges: {charges:.2f} vs statement {target:.2f} '
                     f'{"✓" if ok else "✗ MISMATCH"}   |   '
                     f"credits: {credits:.2f}   |   bill total: {total:.2f}",
                foreground="dark green" if ok else "dark orange")
            return

        text = f"Lines total: {total:.2f}"
        color = "black"
        if self.parsed and self.parsed["total"]:
            target = self.parsed["pre_tax_total"]
            text += (f"   |   PDF pre-tax: {target:.2f}   "
                     f'PDF total (incl. tax): {self.parsed["total"]:.2f}')
            color = "dark green" if abs(total - target) < 0.005 else "dark orange"
        self.totals_label.config(text=text, foreground=color)

    # ---------- entry ----------

    def log(self, message: str):
        self.status.config(state="normal")
        self.status.insert("end", message + "\n")
        self.status.see("end")
        self.status.config(state="disabled")

    def enter_bill(self):
        vendor = self.vendor.get().strip()
        if not vendor:
            messagebox.showwarning("Missing vendor", "Pick a vendor from the dropdown.")
            return
        if self.vendors and vendor not in self.vendors:
            if not messagebox.askyesno(
                    "Vendor not in QuickBooks",
                    f'"{vendor}" is not in the vendor list. QuickBooks will '
                    f"reject the bill unless the vendor exists. Try anyway?"):
                return

        date = self.date.get().strip()
        if date:
            try:
                datetime.strptime(date, "%Y-%m-%d")
            except ValueError:
                messagebox.showwarning("Bad date",
                                       f'Date "{date}" is not YYYY-MM-DD.')
                return

        try:
            lines = [d for d in (row.to_dict() for row in self.rows) if d]
        except ValueError as e:
            messagebox.showwarning("Check lines", str(e).capitalize() + ".")
            return
        if not lines:
            messagebox.showwarning("No lines", "Add at least one line with an "
                                               "Item/Account and an amount.")
            return

        # Reconciliation: a statement whose extracted charges don't add up
        # to its own stated total means lines were missed or edited away.
        # Soft confirmation only — never a blocker.
        if self.parsed and self.parsed["doc_type"] == "statement":
            s = self.parsed["statement"]
            target = s["stated_purchases"] or s["charges_total"]
            charges = sum(l["amount"] for l in lines if l["amount"] > 0)
            if target and abs(charges - target) > 0.005:
                if not messagebox.askyesno(
                        "Totals don't match the statement",
                        f"The charge lines add up to {charges:.2f}, but the "
                        f"statement says {target:.2f} in purchases/charges "
                        f"(difference {charges - target:+.2f}).\n\n"
                        f"Some transactions may be missing or were removed. "
                        f"Enter the bill anyway?"):
                    return

        ref = self.ref.get().strip()
        try:
            if ref and self.qb.bill_exists(vendor, ref):
                if not messagebox.askyesno(
                        "Possible duplicate",
                        f"A bill with ref {ref} already exists for {vendor}. "
                        f"Enter it again anyway?"):
                    return
        except Exception:
            pass  # duplicate check is best-effort, never a blocker

        shown = lines[:12]
        summary = "\n".join(
            f'  {l["kind"]:<8} {l["name"]:<32.32} {l["amount"]:>10.2f}  {l["tax_code"]}'
            for l in shown)
        if len(lines) > len(shown):
            lines_total = sum(l["amount"] for l in lines)
            summary += (f"\n  … and {len(lines) - len(shown)} more lines "
                        f"(total of all {len(lines)} lines: {lines_total:.2f})")
        if not messagebox.askyesno(
                "Confirm bill",
                f"Vendor: {vendor}\nRef: {ref or '(none)'}   Date: {date or 'today'}\n"
                f"\n{summary}\n\nEnter this bill into QuickBooks?"):
            return

        try:
            ok, message = self.qb.add_bill(vendor, ref, date, lines,
                                           memo=self.memo.get().strip())
        except Exception as e:
            ok, message = False, f"QuickBooks error: {e}"
        self.log(message)
        if not ok:
            messagebox.showerror("Not entered", message)
            return

        # Statement lines are per-merchant, so the first line's account says
        # nothing about this vendor (the card issuer) — don't save a default.
        if not (self.parsed and self.parsed["doc_type"] == "statement"):
            self.vendor_defaults[vendor] = {k: lines[0][k]
                                            for k in ("kind", "name", "tax_code")}
            self.vendor_defaults[vendor]["kind"] = self.vendor_defaults[vendor]["kind"].capitalize()
            save_vendor_defaults(self.vendor_defaults)
        messagebox.showinfo("Entered", message)
        self._archive_pdf()

    def _archive_pdf(self):
        """If the PDF lives in an inbox/ folder, offer to move it to done/."""
        if not self.pdf_path or self.pdf_path.parent.name.lower() != "inbox":
            return
        done = self.pdf_path.parent.parent / "done"
        if messagebox.askyesno("Move PDF",
                               f"Move {self.pdf_path.name} to {done}?"):
            done.mkdir(parents=True, exist_ok=True)
            shutil.move(str(self.pdf_path), str(done / self.pdf_path.name))
            self.log(f"Moved to {done / self.pdf_path.name}")
            self.pdf_path = None


def main():
    qb = None
    if QB_AVAILABLE:
        try:
            qb = QuickBooks()
        except Exception as e:
            print(f"Could not connect to QuickBooks: {e}")
    else:
        print("pywin32 not installed — running in preview mode (no QB entry).")

    app = BillEntryApp(qb)
    if len(sys.argv) > 1:
        target = Path(sys.argv[1])
        if target.is_dir():  # e.g. the OneDrive inbox folder
            pdfs = sorted(target.glob("*.pdf")) or sorted(
                (target / "inbox").glob("*.pdf"))
            if pdfs:
                app.after(200, lambda: app.open_pdf(str(pdfs[0])))
        elif target.exists():
            app.after(200, lambda: app.open_pdf(str(target)))
    try:
        app.mainloop()
    finally:
        if qb:
            qb.close()


if __name__ == "__main__":
    main()
