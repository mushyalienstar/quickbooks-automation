@echo off
rem Double-click inside the VM to open the bill entry tool.
rem QuickBooks Desktop should be open with the company file loaded.
cd /d "%~dp0"
python bill_entry_gui.py "C:\Users\finance.automation\Documents\FedExBills\inbox"
pause
