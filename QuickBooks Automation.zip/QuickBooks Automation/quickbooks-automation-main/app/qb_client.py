"""QuickBooks Desktop client (qbXML over the QBXMLRP2 COM component).

All list data — vendors, items, chart of accounts, sales tax codes — is
queried live from whichever company file is open. Nothing about the
company file (item names, tax codes, provinces, accounts) is hardcoded,
so the same build works against any file.
"""
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

QB_AVAILABLE = True
try:
    import win32com.client
except ImportError:
    QB_AVAILABLE = False

# Item types that can't go on a bill's Items tab.
NON_BILLABLE_ITEM_TYPES = {
    "ItemSalesTaxRet", "ItemSalesTaxGroupRet", "ItemPaymentRet",
}


def wrap_qbxml(body: str) -> str:
    return (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<?qbxml version="13.0"?>\n'
        "<QBXML>\n"
        '    <QBXMLMsgsRq onError="stopOnError">\n'
        f"{body}"
        "    </QBXMLMsgsRq>\n"
        "</QBXML>\n"
    )


def build_bill_add_qbxml(vendor: str, ref_number: str, txn_date: str,
                         lines: list, memo: str = "") -> str:
    """qbXML BillAddRq from generic line dicts (see QuickBooks.add_bill).
    Element order follows the qbXML 13.0 spec — expense lines before item
    lines, SalesTaxCodeRef after Amount."""
    expense_xml, item_xml = "", ""
    for line in lines:
        tax = ""
        if line.get("tax_code"):
            tax = (f"\n                <SalesTaxCodeRef>"
                   f"<FullName>{escape(line['tax_code'])}</FullName>"
                   f"</SalesTaxCodeRef>")
        if line["kind"] == "expense":
            note = ""
            if line.get("memo"):
                note = f"\n                <Memo>{escape(line['memo'])}</Memo>"
            expense_xml += f"""
            <ExpenseLineAdd>
                <AccountRef><FullName>{escape(line['name'])}</FullName></AccountRef>
                <Amount>{line['amount']:.2f}</Amount>{note}{tax}
            </ExpenseLineAdd>"""
        else:
            note = ""
            if line.get("memo"):
                note = f"\n                <Desc>{escape(line['memo'])}</Desc>"
            item_xml += f"""
            <ItemLineAdd>
                <ItemRef><FullName>{escape(line['name'])}</FullName></ItemRef>{note}
                <Amount>{line['amount']:.2f}</Amount>{tax}
            </ItemLineAdd>"""

    memo_xml = f"\n                <Memo>{escape(memo)}</Memo>" if memo else ""
    date_xml = f"\n                <TxnDate>{txn_date}</TxnDate>" if txn_date else ""
    ref_xml = (f"\n                <RefNumber>{escape(ref_number)}</RefNumber>"
               if ref_number else "")
    body = f"""        <BillAddRq>
            <BillAdd>
                <VendorRef><FullName>{escape(vendor)}</FullName></VendorRef>{date_xml}{ref_xml}{memo_xml}{expense_xml}{item_xml}
            </BillAdd>
        </BillAddRq>
"""
    return wrap_qbxml(body)


class QuickBooks:
    """One open session against the currently-open company file."""

    def __init__(self, app_name: str = "Bill Entry"):
        if not QB_AVAILABLE:
            raise RuntimeError("pywin32 is not installed — run `pip install "
                               "pywin32` on the machine with QuickBooks Desktop.")
        self.qb = win32com.client.Dispatch("QBXMLRP2.RequestProcessor")
        self.qb.OpenConnection2("", app_name, 1)
        self.ticket = self.qb.BeginSession("", 2)

    def request(self, qbxml: str) -> str:
        return self.qb.ProcessRequest(self.ticket, qbxml)

    def close(self):
        try:
            self.qb.EndSession(self.ticket)
        finally:
            self.qb.CloseConnection()

    def host_info(self) -> str:
        try:
            root = ET.fromstring(self.request(wrap_qbxml("        <HostQueryRq/>\n")))
            ret = root.find(".//HostRet")
            if ret is None:
                return ""
            return ret.findtext("ProductName", "")
        except Exception:
            return ""

    def _query_names(self, rq_tag: str, extra: str = "",
                     skip_ret_tags: set = frozenset()) -> list:
        """FullName/Name of every entry a list query returns."""
        qbxml = wrap_qbxml(f"        <{rq_tag}>\n{extra}        </{rq_tag}>\n")
        root = ET.fromstring(self.request(qbxml))
        rs = root.find(f".//{rq_tag[:-2]}Rs")
        names = []
        if rs is None:
            return names
        for ret in rs:
            if ret.tag in skip_ret_tags:
                continue
            name = ret.findtext("FullName") or ret.findtext("Name")
            if name and name not in names:
                names.append(name)
        return names

    # ---- live lists (the source of truth for the entry form's dropdowns) ----

    def vendors(self) -> list:
        return sorted(self._query_names(
            "VendorQueryRq", "            <ActiveStatus>ActiveOnly</ActiveStatus>\n"),
            key=str.lower)

    def items(self) -> list:
        return sorted(self._query_names(
            "ItemQueryRq", "            <ActiveStatus>ActiveOnly</ActiveStatus>\n",
            skip_ret_tags=NON_BILLABLE_ITEM_TYPES), key=str.lower)

    def accounts(self) -> list:
        return sorted(self._query_names(
            "AccountQueryRq", "            <ActiveStatus>ActiveOnly</ActiveStatus>\n"),
            key=str.lower)

    def tax_codes(self) -> list:
        return sorted(self._query_names(
            "SalesTaxCodeQueryRq",
            "            <ActiveStatus>ActiveOnly</ActiveStatus>\n"), key=str.lower)

    # ---- bill entry ----

    def bill_exists(self, vendor: str, ref_number: str) -> bool:
        """True if this vendor already has a bill with this ref number."""
        if not ref_number:
            return False
        qbxml = wrap_qbxml(
            "        <BillQueryRq>\n"
            f"            <RefNumber>{escape(ref_number)}</RefNumber>\n"
            "        </BillQueryRq>\n")
        root = ET.fromstring(self.request(qbxml))
        for ret in root.findall(".//BillRet"):
            if not vendor or ret.findtext("VendorRef/FullName") == vendor:
                return True
        return False

    def add_bill(self, vendor: str, ref_number: str, txn_date: str,
                 lines: list, memo: str = "") -> tuple:
        """Enter a vendor bill. Each line is a dict:
            {"kind": "item"|"expense", "name": <Item/Account FullName>,
             "amount": float, "tax_code": str (optional), "memo": str (optional)}
        Returns (ok, message)."""
        qbxml = build_bill_add_qbxml(vendor, ref_number, txn_date, lines, memo)
        response = self.request(qbxml)
        rs = ET.fromstring(response).find(".//BillAddRs")
        if rs is None:
            return False, f"Unexpected response:\n{response}"
        if rs.get("statusCode") == "0":
            total = rs.findtext(".//BillRet/AmountDue", "")
            suffix = f" (bill total {total})" if total else ""
            return True, f"Bill added to QuickBooks{suffix}."
        return False, (f"QuickBooks rejected the bill "
                       f"(status {rs.get('statusCode')}): {rs.get('statusMessage')}")
